<?php
session_start();
/*$days=array(array(0,0));
for($i=1;$i<=date('t');$i++)
{
array_push($days,array(date('Y-m').$i,0));
}*/
$db = new SQLite3('/var/www/html/exercise.db');//呼叫資料庫 
$month_s=date('Y-m')."-01".' '.'00:00:00';
$month_e=date('Y-m')."-".date('t').' '.'23:59:59';
$time="SELECT * FROM milage_thismonth WHERE Date between '".$month_s."' AND '".$month_e."' ";
$temp=$db->query($time);
/*while($month=$temp->fetchArray())
{
for($i=0;$i<date('t');$i++)
{
if($month[''])
}
}*/
?> 
<!DOCTYPE html>
 <html> 
<head>
 <meta charset="UTF-8"> 
<script type="text/javascript" src="http://code.jquery.com/jquery-1.8.3.min.js"></script> 
<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>
<title>個人圖表</title>
</head> 
<script> 
$(function () {
    $('#container').highcharts({
        chart: {
            zoomType: 'xy'
        },
        title: {
            text: 'Average Monthly Temperature and Rainfall in Tokyo'
        },
        subtitle: {
            text: 'Source: WorldClimate.com'
        },
        xAxis: [{
            categories: [<?php
		for($i=1;$i<=date('t');$i++)
		{
		echo $i."日".",";
			}
		?>],
            crosshair: true
        }],
        yAxis: [{ // Primary yAxis
            labels: {
                format: '{value}°C',
                style: {
                    color: Highcharts.getOptions().colors[1]
                }
            },
            title: {
                text: 'Temperature',
                style: {
                    color: Highcharts.getOptions().colors[1]
                }
            }
        }, { // Secondary yAxis
            title: {
                text: 'Rainfall',
                style: {
                    color: Highcharts.getOptions().colors[0]
                }
            },
            labels: {
                format: '{value} mm',
                style: {
                    color: Highcharts.getOptions().colors[0]
                }
            },
            opposite: true
        }],
        tooltip: {
            shared: true
        },
        legend: {
            layout: 'vertical',
            align: 'left',
            x: 120,
            verticalAlign: 'top',
            y: 100,
            floating: true,
            backgroundColor: (Highcharts.theme && Highcharts.theme.legendBackgroundColor) || '#FFFFFF'
        },
        series: [{
            name: 'Rainfall',
            type: 'column',
            yAxis: 1,
            data: [
		<?php
		 while($month=$temp->fetchArray())
		{
		echo $month['miles'].",";
		}?>],
            tooltip: {
                valueSuffix: ' m'
            }
        }, {
            name: 'Temperature',
            type: 'spline',
            data: [
		<?php
		 while($month=$temp->fetchArray())
                {
                echo $month['Kcal'].",";
                }?>],
            tooltip: {
                valueSuffix: 'Kcal'
            }
        }]
    });
});
</script>
<body>
<div id="container" style="min-width: 310px; height: 400px; margin: 0 auto"></div>
<?php $db->close(); ?>
</body> 
</html>
