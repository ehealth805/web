<!DOCTYPE html>
<?php
session_start();
?>
<html>
<head>
<meta charset="UTF-8">
<title>智慧跑道系統</title>
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css"><!--匯入bootstrap-->
<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script><!--匯入jQuery-->
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script><!--匯入bootstrap javascript-->

<script  type="text/javascript" src="http://code.jquery.com/jquery-1.8.3.min.js"></script>
<script  type="text/javascript" src="https://code.highcharts.com/highcharts.js"></script>
<script  type="text/javascript" src="https://code.highcharts.com/modules/data.js"></script>
<script  type="text/javascript" src="https://code.highcharts.com/modules/drilldown.js"></script>


<style type="text/css">
	h1 {
		text-align:center;
		background:#555;
		color:white;
		}
		h2{
		text-align:center;
		font-size:25px;
		}
	.title{
		text-align:right;
		color:black;
		font-size:25px;
		}
		
	nav {
		text-align:center;
		float: left;
		max-width: 200px;
	}
	article{
    margin-left: 170px;
	margin-right:100px;
    padding: 1em;
    overflow: hidden;
}
.nav2{
	text-align:center;
	float: right;
	min-width:200px;
}
/*body {
	background-image : url(back6.png);
	background-repeat:no-repeat;
	background-color : rgba(0,0,0,1) ;
	background-size:cover;
}*/
</style>
</head>
<body>
<?php 
if(empty($_POST))
{
	$type=1;
 $db = new SQLite3('/var/www/html/exercise.db');//呼叫資料庫
$temp="SELECT * From userdata WHERE SID='".$_SESSION['SID']."' AND CID='".$_SESSION['CID']."' ";
    $temp=$db->query($temp);
    $result=$temp->fetchArray();	
echo '2222';
}
else
{
	echo '11111';
    $db = new SQLite3('/var/www/html/exercise.db');//呼叫資料庫
    $sn="SELECT CampusId From campus_detail WHERE CampusName='".$_POST['school']."' ";
    $snt=$db->query($sn);
    $sntr=$snt->fetchArray();
    $temp="SELECT * From userdata WHERE SID='".$_POST['ID']."' AND birth='".$_POST['birthday']."' AND CID='".$sntr['CampusId']."' ";
    $temp=$db->query($temp);
    $result=$temp->fetchArray();
        if($result)
        {
			$type=1;
		if($_SESSION['views']==0)
		{
		$_SESSION['school_name']=$_POST['school'];
		$_SESSION['SID']=$_POST['ID'];
		$_SESSION['CID']=$sntr['CampusId'];
		}
		}
        else
        {$type=2;}
}
if($type==1)
{

// $s="select CampusId FROM campus_detail WHERE CampusName='".$_SESSION['school_name']."'";//抓取學校編碼
// $temp=$db->query($s);
// $cid=$temp->fetchArray();
echo '
<header>
<br>
</p>
<ul class="nav nav-tabs">
<div class="navbar-header">
                <a class="navbar-brand" href="#">';
				echo $_SESSION['school_name'];
echo '
		</a>
            </div>
        <li><a href="home_page_student_v2.php">Home</a></li>
        <li><a href="user_data.php"><span class="glyphicon glyphicon-log-in"></span> 使用者資訊查詢</a></li>
        <li><a href="sportdata_search_date.php"><span class="glyphicon glyphicon-search"></span> 運動紀錄查詢</a></li>
		<li class="dropdown"><a lass="dropdown-toggle" data-toggle="dropdown" >
		<span class="glyphicon glyphicon-align-justify"></span> 分析排名<span class="caret"></span></a>
				<ul class="dropdown-menu">
				<li><a href="eight_hundred.php">心肺800M</a></li>
				<li><a href="eight_hundred_v2.php">心肺1600M</a></li>
                <li><a href="eight_hundred_v3.php">耐力3KM</a></li>
				<li><a href="#">耐力5KM</a></li>
				<li><a href="#">耐力10KM</a></li>
		</li></ul>
	<li class="dropdown"><a lass="dropdown-toggle" data-toggle="dropdown" >
        <span class="glyphicon glyphicon-align-justify"></span> 個人圖表<span class="caret"></span></a>
                <ul class="dropdown-menu">
	            <li><a href="#">月累積</a></li>
        	    <li><a href="#">年累積</a></li>
                </li></ul></ul>
<p class="title">
您好，
<a href="login_v2.php">登出</a></p>
</header>
<nav>
<ul class="list-group ">
　<li class="list-group-item list-group-item-action list-group-item-warning">當月累積排名
　<li class="list-group-item list-group-item-action list-group-item-warning">第一名 姓名 學校 里程數</li>
<li class="list-group-item list-group-item-action list-group-item-warning">第二名 姓名 學校 里程數
<li class="list-group-item list-group-item-action list-group-item-warning">第三名 姓名 學校 里程數 
</ul>
</nav>';
echo'
<ul class="nav2">
<li class="list-group-item list-group-item-action list-group-item-warning">個人資料
<li class="list-group-item list-group-item-action list-group-item-warning">學號：';echo  $result['SID'];
echo'</li>
<li class="list-group-item list-group-item-action list-group-item-warning">姓名：';echo  $result['Name'];
echo'
<li class="list-group-item list-group-item-action list-group-item-warning">班別：';echo  $result['Department'];
echo'
<li class="list-group-item list-group-item-action list-group-item-warning">性別：';
if($result['sex']=="1")
echo  '男';
else
	echo  '女';
echo'
<li class="list-group-item list-group-item-action list-group-item-warning">身高：';echo  $result['height'];
echo'
<li class="list-group-item list-group-item-action list-group-item-warning">體重：';echo  $result['weight'];
echo'
<li class="list-group-item list-group-item-action list-group-item-warning">Email：';echo  $result['email'];
echo'
<li class="list-group-item list-group-item-action list-group-item-warning">晶片編碼：';echo  $result['tagid'];
echo'
</ul>
<article>
// <div id="container" style="max-width: 700x; height: 350px"></div>
</article>
<footer class="bg-info" style="text-align:center">Copyright 智慧跑道系統</footer>
<center>
</body>
</html>';
}
else if($type==2)
{
echo '<h1 align="center">登入錯誤!請重新登入!</h1><h2><a href="login_v2.php">回上一頁</a></h2>';	
}
$db->close();
?>

