<!DOCTYPE html>
<?php
session_start();

if($_SESSION['views']==0)
		{
			$db = new SQLite3('/var/www/html/exercise.db');//呼叫資料庫
			$sn="SELECT CampusId From campus_detail WHERE CampusName='".$_POST['school']."' ";
			$snt=$db->query($sn);
			$sntr=$snt->fetchArray();
		$_SESSION['SID']=$_POST['ID'];
		$_SESSION['CID']=$sntr['CampusId'];
		
		}
$days=array(array(0,0,0));
for($i=1;$i<=date('t');$i++) {
if($i>=1 && $i<10) 
array_push($days,array(date('Y-m')."-0".$i,0,0)); 
else
	array_push($days,array(date('Y-m')."-".$i,0,0));
}
$db = new SQLite3('/var/www/html/exercise.db');//呼叫資料庫
 $month_s=date('Y-m')."-01".' '.'00:00:00'; 
$month_e=date('Y-m-S').' '.'23:59:59';
 $time="SELECT * FROM sportdata WHERE Date between '".$month_s."' AND '".$month_e."' AND SID='".$_SESSION['SID']."' AND CID='".$_SESSION['CID']."' ";
 $temp=$db->query($time); 
while($month=$temp->fetchArray()) { 
for($i=1;$i<=date('t');$i++) {
	$change=strtotime($month['Date']);
	if(date('Y-m-d',$change)==$days[$i][0])
	{
		$days[$i][1]+=$month['Rundistance']+$month['Walkdistance'];
		$days[$i][2]+=$month['Kcal'];
	}
}
}
//-------------------------------------------------------------------以上為當月份 
?>
<html>
<head>
<meta charset="UTF-8">
<title>智慧跑道系統</title>
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css"><!--匯入bootstrap-->
<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script><!--匯入jQuery-->
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script><!--匯入bootstrap javascript-->

<script  type="text/javascript" src="http://code.jquery.com/jquery-1.8.3.min.js"></script>
<script  type="text/javascript" src="https://code.highcharts.com/highcharts.js"></script>
<script  type="text/javascript" src="https://code.highcharts.com/modules/data.js"></script>
<script  type="text/javascript" src="https://code.highcharts.com/modules/drilldown.js"></script>


<style type="text/css">
	h1 {
		text-align:center;
		background:#555;
		color:white;
		}
		h2{
		text-align:center;
		font-size:25px;
		}
	.title{
		text-align:right;
		color:black;
		font-size:25px;
		}
		
	nav {
		text-align:center;
		float: left;
		max-width: 250px;
	}
	article{
    margin-left: 170px;
	margin-right:100px;
    padding: 1em;
    overflow: hidden;
}
.nav2{
	text-align:center;
	float: right;
	min-width:200px;
}
/*body {
	background-image : url(back6.png);
	background-repeat:no-repeat;
	background-color : rgba(0,0,0,1) ;
	background-size:cover;
}*/
</style>
</head>
<script>
 $(function () {
    $('#container').highcharts({
        chart: {
            zoomType: 'xy'
        },
        title: {
            text: '<?php echo date('Y-m')."月紀錄" ;?>'
        },
        subtitle: {
            text: 'Source:智慧跑道系統'
        },
        xAxis: [{
            categories: [<?php
		for($i=1;$i<=date('t');$i++)
		{
		echo $i.",";
			}
		?>],
            crosshair: true
        }],
        yAxis: [{ // Primary yAxis
            labels: {
                format: '{value} Kcal',
                style: {
                    color: Highcharts.getOptions().colors[1]
                }
            },
            title: {
                text: '卡路里',
                style: {
                    color: Highcharts.getOptions().colors[1]
                }
            }
        }, { // Secondary yAxis
            title: {
                text: '里程數',
                style: {
                    color: Highcharts.getOptions().colors[0]
                }
            },
            labels: {
                format: '{value} m',
                style: {
                    color: Highcharts.getOptions().colors[0]
                }
            },
            opposite: true
        }],
        tooltip: {
            shared: true
        },
        legend: {
            layout: 'vertical',
            align: 'left',
            x: 120,
            verticalAlign: 'top',
            y: 100,
            floating: true,
            backgroundColor: (Highcharts.theme && Highcharts.theme.legendBackgroundColor) || '#FFFFFF'
        },
        series: [{
            name: '里程數',
            type: 'column',
            yAxis: 1,
            data: [
		<?php
		 for($i=1;$i<=date('t');$i++)
		{
		echo $days[$i][1].",";
		}?>],
            tooltip: {
                valueSuffix: ' m'
            }
        }, {
            name: '卡路里',
            type: 'spline',
            data: [
		<?php
		 for($i=1;$i<=date('t');$i++)
                {
                echo $days[$i][2].",";
                }?>],
            tooltip: {
                valueSuffix: 'Kcal'
            }
        }]
    });
});
</script>
<body>
<?php
function find_school_name($temp) {
$db = new SQLite3('/var/www/html/exercise.db');
$school="SELECT CampusName FROM campus_detail WHERE CampusId = '".$temp."' ";
$temps=$db->query($school);
$s_name=$temps->fetchArray();
return $s_name['CampusName'];
}
?>

<?php 
if(empty($_POST))
{
	$type=1;
$db = new SQLite3('/var/www/html/exercise.db');//呼叫資料庫
$temp="SELECT * From userdata WHERE SID='".$_SESSION['SID']."' AND CID='".$_SESSION['CID']."' ";
    $temp=$db->query($temp);
    $result=$temp->fetchArray();	
//echo '2222';
}
else
{
//	echo '11111';
    $db = new SQLite3('/var/www/html/exercise.db');//呼叫資料庫
    $sn="SELECT CampusId From campus_detail WHERE CampusName='".$_POST['school']."' ";
    $snt=$db->query($sn);
    $sntr=$snt->fetchArray();
    $temp="SELECT * From userdata WHERE SID='".$_POST['ID']."' AND birth='".$_POST['birthday']."' AND CID='".$sntr['CampusId']."' AND position='1' ";
    $temp=$db->query($temp);
    $result=$temp->fetchArray();
        if($result)
        {
			$type=1;
		if($_SESSION['views']==0)
		{
		$_SESSION['school_name']=$_POST['school'];
		$_SESSION['SID']=$_POST['ID'];
		$_SESSION['CID']=$sntr['CampusId'];
		
		}
		}
        else
        {$type=2;}
}
if($type==1)
{

$month_now=date('Y-m');
 $s="select * FROM milage_thisyear  WHERE year='".$month_now."' ORDER BY miles DESC";
 $temp=$db->query($s);
echo '
<header>
<br>
</p>
<ul class="nav nav-tabs">
<div class="navbar-header">
                <a class="navbar-brand" href="#">';
				echo $_SESSION['school_name'];
echo '
		</a>
            </div>
        <li><a href="home_page_student_v2.php">Home</a></li>
        <li><a href="user_data.php"><span class="glyphicon glyphicon-log-in"></span> 使用者資訊查詢</a></li>
        <li><a href="sportdata_search_date.php"><span class="glyphicon glyphicon-search"></span> 運動紀錄查詢</a></li>
		<li class="dropdown"><a lass="dropdown-toggle" data-toggle="dropdown" >
		<span class="glyphicon glyphicon-align-justify"></span> 分析排名<span class="caret"></span></a>
				<ul class="dropdown-menu">
				<li><a href="eight_hundred.php">心肺800M</a></li>
				<li><a href="eight_hundred_v2.php">心肺1600M</a></li>
                <li><a href="eight_hundred_v3.php">耐力3KM</a></li>
				<li><a href="#">耐力5KM</a></li>
				<li><a href="#">耐力10KM</a></li>
		</li></ul>
	<li class="dropdown"><a lass="dropdown-toggle" data-toggle="dropdown" >
        <span class="glyphicon glyphicon-align-justify"></span> 個人圖表<span class="caret"></span></a>
                <ul class="dropdown-menu">
	            <li><a href="personal_mileage.php">月累積</a></li>
        	    <li><a href="year_mileages.php">年累積</a></li>
                </li></ul></ul>
<p class="title">
您好，
<a href="login_v2.php">登出</a></p>
</header>';
$count=1;
echo '
<nav>
<ul class="list-group ">
　<li class="list-group-item list-group-item-action list-group-item-warning">';echo date('m');echo '月累積排名';
	while($show_month=$temp->fetchArray())
{
if($count<11)
{
echo '<li class="list-group-item list-group-item-action list-group-item-warning">
	第';echo $count;echo '名  ';
	$s_n = find_school_name($show_month['CID']);
	echo $show_month['Name']." ".$s_n." ".$show_month['miles']."公尺";
	echo ' </li>';
$count++;
}}
echo '
</ul>
</nav>';
echo'
<ul class="nav2">
<li class="list-group-item list-group-item-action list-group-item-warning">個人資料
<li class="list-group-item list-group-item-action list-group-item-warning">學號：';echo  $result['SID'];
echo'</li>
<li class="list-group-item list-group-item-action list-group-item-warning">姓名：';echo  $result['Name'];
echo'
<li class="list-group-item list-group-item-action list-group-item-warning">班別：';echo  $result['Department'];
echo'
<li class="list-group-item list-group-item-action list-group-item-warning">性別：';
if($result['sex']=="1")
echo  '男';
else
	echo  '女';
echo'
<li class="list-group-item list-group-item-action list-group-item-warning">身高：';echo  $result['height'];
echo'
<li class="list-group-item list-group-item-action list-group-item-warning">體重：';echo  $result['weight'];
echo'
<li class="list-group-item list-group-item-action list-group-item-warning">Email：';echo  $result['email'];
echo'
<li class="list-group-item list-group-item-action list-group-item-warning">晶片編碼：';echo  $result['tagid'];
echo'
</ul>
<article>';

echo '
 <div id="container" style="min-width: 300px; height: 300px; margin: 0 auto"></div> ';
echo '</article>
<footer class="bg-info" style="text-align:center">Copyright 智慧跑道系統</footer>
<center>
</body>
</html>';
}
else if($type==2)
{
echo '<h1 align="center">登入錯誤!請重新登入!</h1><h2><a href="login_v2.php">回上一頁</a></h2>';	
}
?>
<?php
$db->close();
?>
