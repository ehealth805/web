<?php 
header("Content-Type:text/html; charset=utf-8");
session_start();
$year_select=array();
	for($i=0;$i<5;$i++)
	{
		array_push($year_select,date('Y')+$i-4);
	//	echo $year_select[$i]."<br>";
	}
$month=array(array(0,0));
for($i=1;$i<=12;$i++)
	{
		if($i>=1 && $i<10)
		{
			array_push($month,array(date('Y-')."0".$i,0));
		}
		else
			array_push($month,array(date('Y-').$i,0));
		//echo $month[$i][0]."<br>";
	}
if(!$_POST['year'])
{       $year_r=date('Y');
//echo $year_r."1"."<br>";
}
else
{       $year_r=$_POST['year'];
//echo $year_r."2"."<br>";
}
$db = new SQLite3('/var/www/html/exercise.db');//呼叫資料庫
$year_s=$year_r."-01-01".' '.'00:00:00';
$year_e=$year_r."-12-31".' '.'23:59:59';
$time="SELECT * FROM sportdata  WHERE Date between '".$year_s."' AND '".$year_e."' AND SID='".$_SESSION['SID']."' AND CID='".$_SESSION['CID']."' ";
$temp=$db->query($time);
while($year_s=$temp->fetchArray())
{
        for($i=1;$i<=12;$i++)
        {
         $change=strtotime($year_s['Date']);
        //echo date('Y-m',$change)."<br>";
			if(date('Y-m',$change)==$month[$i][0])
			{
                      $month[$i][1]+=$year_s['Rundistance']+$year_s['Walkdistance'];
  //              echo  $month[$i][1].$month[$i][0].$year_s['Date']."<br>";
			}
		}
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
 <script type="text/javascript" src="http://code.jquery.com/jquery-1.8.3.min.js"></script>
<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>
<script  type="text/javascript" src="https://code.highcharts.com/modules/drilldown.js"></script>
<title>個人年累積</title>
<script>
$(function () {
	 Highcharts.setOptions({
        colors: ['#6AF9C4']
    });
    $('#container').highcharts({
        chart: {
            type: 'line'
        },
        title: {
            text: '<?php echo $year_r; ?>Monthly Average miles'
        },
        subtitle: {
            text: ' Source:智慧跑道系統 '
        },
        xAxis: {
            categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
        },
        yAxis: {
            title: {
                text: '里程數 (m)'
            }
        },
	        tooltip:
        {
        crosshairs: true,
            shared: true,
        valueSuffix: ' m'
        },


        plotOptions: {
            line: {
                dataLabels: {
                    enabled: true
                },
                enableMouseTracking: true
            }
        },
        series: [{
            name: '<?php echo $_SESSION['SID'];?>',
            data: [<?php
		 for($i=1;$i<=12;$i++)
                {
                echo $month[$i][1].",";
                }?>]}]
    });
});
</script>
</head>
<body>
<center>
<form id="choose_year" action="year_mileages.php" method="post"> 
請選擇年份：
<select name="year" >
<?php
for($i=0;$i<5;$i++)
{
	if($year_select[$i]==date('Y'))
		echo "<option value=".$year_select[$i]." selected>".$year_select[$i]."</option>\n";
		else
        echo "<option value=".$year_select[$i].">".$year_select[$i]."</option>\n";
}
?>
</select>
<p><input type="submit" value="選擇">
<div id="container" style="min-width: 310px; height: 400px; margin: 0 auto"></div>
</form>

<a href="home_page_student_v2.php" ><img src="Home.png" width="50" height="50" align="center"><br></a>回主畫面
</center>
<?php
$db->close();
?>
</body>
</html>
