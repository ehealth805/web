<?php 
session_start(); 
$days=array(array(0,0,0));
 for($i=1;$i<=date('t');$i++) {
 if($i>=1 && $i<10) 
array_push($days,array(date('Y-m')."-0".$i,0,0)); 
else
	array_push($days,array(date('Y-m')."-".$i,0,0));
}
$db = new SQLite3('/var/www/html/exercise.db');//呼叫資料庫
 $month_s=date('Y-m')."-01".' '.'00:00:00'; 
$month_e=date('Y-m-S').' '.'23:59:59';
 $time="SELECT * FROM sportdata WHERE Date between '".$month_s."' AND '".$month_e."' AND SID='102316230' ";
 $temp=$db->query($time); 
while($month=$temp->fetchArray()) { 
for($i=1;$i<=date('t');$i++) {
	$change=strtotime($month['Date']);
	if(date('Y-m-d',$change)==$days[$i][0])
	{
		$days[$i][1]+=$month['Rundistance']+$month['Walkdistance'];
		$days[$i][2]+=$month['Kcal'];
		//echo '1';
	}
}
}
//-------------------------------------------------------------------以上為當月份 ?> 
<!DOCTYPE html>
 <html>
 <head>
 <meta charset="UTF-8">
 <script type="text/javascript" src="http://code.jquery.com/jquery-1.8.3.min.js"></script>
 <script type="text/javascript" src="https://code.highcharts.com/highcharts.js"></script>
 <script type="text/javascript" src="https://code.highcharts.com/modules/exporting.js"></script> 
<script type="text/javascript" src="https://code.highcharts.com/modules/drilldown.js"></script> 
<title>個人月累積</title>
 </head>
 <script> $(function () {
    $('#container').highcharts({
        chart: {
            zoomType: 'xy'
        },
        title: {
            text: '<?php echo date('Y-m')."月紀錄" ;?>'
        },
        subtitle: {
            text: 'Source:智慧跑道系統'
        },
        xAxis: [{
            categories: [<?php
		for($i=1;$i<=date('t');$i++)
		{
		echo $i.",";
			}
		?>],
            crosshair: true
        }],
        yAxis: [{ // Primary yAxis
            labels: {
                format: '{value} Kcal',
                style: {
                    color: Highcharts.getOptions().colors[1]
                }
            },
            title: {
                text: '卡路里',
                style: {
                    color: Highcharts.getOptions().colors[1]
                }
            }
        }, { // Secondary yAxis
            title: {
                text: '里程數',
                style: {
                    color: Highcharts.getOptions().colors[0]
                }
            },
            labels: {
                format: '{value} m',
                style: {
                    color: Highcharts.getOptions().colors[0]
                }
            },
            opposite: true
        }],
        tooltip: {
            shared: true
        },
        legend: {
            layout: 'vertical',
            align: 'left',
            x: 120,
            verticalAlign: 'top',
            y: 100,
            floating: true,
            backgroundColor: (Highcharts.theme && Highcharts.theme.legendBackgroundColor) || '#FFFFFF'
        },
        series: [{
            name: '里程數',
            type: 'column',
            yAxis: 1,
            data: [
		<?php
		 for($i=1;$i<=date('t');$i++)
		{
		echo $days[$i][1].",";
		}?>],
            tooltip: {
                valueSuffix: ' m'
            }
        }, {
            name: '卡路里',
            type: 'spline',
            data: [
		<?php
		 for($i=1;$i<=date('t');$i++)
                {
                echo $days[$i][2].",";
                }?>],
            tooltip: {
                valueSuffix: 'Kcal'
            }
        }]
    });
});
</script>
 <body> 
<div id="container" style="min-width: 310px; height: 400px; margin: 0 auto"></div> 
<?php 
$db->close();
 ?>
 </body>
 </html>
