<?php
session_start();
$days=array(array(0,0,0));
for($i=1;$i<=date('t');$i++)
{
if($i>=1 && $i<10)
array_push($days,array(date('Y-m')."-0".$i,0,0));
else 
	array_push($days,array(date('Y-m')."-".$i,0,0));
}

$db = new SQLite3('/var/www/html/exercise.db');//呼叫資料庫 
$month_s=date('Y-m')."-01".' '.'00:00:00';
$month_e=date('Y-m-S').' '.'23:59:59';
$time="SELECT * FROM sportdata  WHERE Date between '".$month_s."' AND '".$month_e."' AND SID='".$_SESSION['SID']."' AND CID='".$_SESSION['CID']."'  ";
$temp=$db->query($time);
while($month=$temp->fetchArray())
{
for($i=1;$i<=date('t');$i++)
{
	$change=strtotime($month['Date']);	
	if(date('Y-m-d',$change)==$days[$i][0])
	{
		$days[$i][1]+=$month['Rundistance']+$month['Walkdistance'];
		$days[$i][2]+=$month['Kcal'];
		//echo '1';
	}
}
}
//-------------------------------------------------------------------以上為當月份
$previous=date('m')-1;//上一個月份
if($previous>=1 && $previous<10)
{
$previous="0".$previous;
}
$ex_m= date('t', strtotime(date('Y')."-".$previous));//上一個月的天數
$days_ex=array(array(0,0,0));
for($i=1;$i<=$ex_m;$i++)
{
if($i>=1 && $i<10)
array_push($days_ex,array(date('Y-').$previous."-0".$i,0,0));
else
        array_push($days_ex,array(date('Y-').$previous."-".$i,0,0));
}

$month_s=$days_ex[1][0].' '.'00:00:00';
$month_e=$days_ex[$ex_m][0].' '.'23:59:59';
$time="SELECT * FROM sportdata  WHERE Date between '".$month_s."' AND '".$month_e."' AND SID='".$_SESSION['SID']."' AND CID='".$_SESSION['CID']."' ";
$temp=$db->query($time);
while($month_ex=$temp->fetchArray())
{
for($i=1;$i<=$ex_m;$i++)
{
        $change=strtotime($month_ex['Date']);
        if(date('Y-m-d',$change)==$days_ex[$i][0])
        {
                $days_ex[$i][1]+=$month_ex['Rundistance']+$month['Walkdistance'];
                $days_ex[$i][2]+=$month_ex['Kcal'];
        }
}
}
//-------------------------------------------------------------------以上為上個月份
/*for($i=1;$i<=$ex_m;$i++)
{
echo $days_ex[$i][0].$days_ex[$i][1]."<br>";
}*/
?>
<!DOCTYPE html> 
 <html>
 <head>
 <meta charset="UTF-8">
 <script type="text/javascript" src="http://code.jquery.com/jquery-1.8.3.min.js"></script>
 <script type="text/javascript" src="https://code.highcharts.com/highcharts.js"></script>
 <script type="text/javascript" src="https://code.highcharts.com/modules/exporting.js"></script> 
<script  type="text/javascript" src="https://code.highcharts.com/modules/drilldown.js"></script>
<title>個人圖表</title> 
</head> 
<script> 
$(function () {
    $('#container').highcharts({
        chart: {
            zoomType: 'xy'
        },
        title: {
            text: '<?php echo date('Y-m')."月紀錄" ;?>'
        },
        subtitle: {
            text: 'Source:智慧跑道系統'
        },
        xAxis: [{
            categories: [<?php
		for($i=1;$i<=date('t');$i++)
		{
		echo $i.",";
			}
		?>],
            crosshair: true
        }],
        yAxis: [{ // Primary yAxis
            labels: {
                format: '{value} Kcal',
                style: {
                    color: Highcharts.getOptions().colors[1]
                }
            },
            title: {
                text: '卡路里',
                style: {
                    color: Highcharts.getOptions().colors[1]
                }
            }
        }, { // Secondary yAxis
            title: {
                text: '里程數',
                style: {
                    color: Highcharts.getOptions().colors[0]
                }
            },
            labels: {
                format: '{value} m',
                style: {
                    color: Highcharts.getOptions().colors[0]
                }
            },
            opposite: true
        }],
        tooltip: {
            shared: true
        },
        legend: {
            layout: 'vertical',
            align: 'left',
            x: 120,
            verticalAlign: 'top',
            y: 100,
            floating: true,
            backgroundColor: (Highcharts.theme && Highcharts.theme.legendBackgroundColor) || '#FFFFFF'
        },
        series: [{
            name: '里程數',
            type: 'column',
            yAxis: 1,
            data: [
		<?php
		 for($i=1;$i<=date('t');$i++)
		{
		echo $days[$i][1].",";
		}?>],
            tooltip: {
                valueSuffix: ' m'
            }
        }, {
            name: '卡路里',
            type: 'spline',
            data: [
		<?php
		 for($i=1;$i<=date('t');$i++)
                {
                echo $days[$i][2].",";
                }?>],
            tooltip: {
                valueSuffix: 'Kcal'
            }
        }]
    });
});
</script>
<script> 
$(function () {
    $('#container2').highcharts({
        chart: {
            zoomType: 'xy'
        },
        title: {
            text: '<?php echo date('Y-').$previous."月紀錄" ;?>'
        },
        subtitle: {
            text: 'Source:智慧跑道系統'
        },
        xAxis: [{
            categories: [<?php
		for($i=1;$i<=date('t');$i++)
		{
		echo $i.",";
			}
		?>],
            crosshair: true
        }],
        yAxis: [{ // Primary yAxis
            labels: {
                format: '{value} Kcal',
                style: {
                    color: Highcharts.getOptions().colors[1]
                }
            },
            title: {
                text: '卡路里',
                style: {
                    color: Highcharts.getOptions().colors[1]
                }
            }
        }, { // Secondary yAxis
            title: {
                text: '里程數',
                style: {
                    color: Highcharts.getOptions().colors[0]
                }
            },
            labels: {
                format: '{value} m',
                style: {
                    color: Highcharts.getOptions().colors[0]
                }
            },
            opposite: true
        }],
        tooltip: {
            shared: true
        },
        legend: {
            layout: 'vertical',
            align: 'left',
            x: 120,
            verticalAlign: 'top',
            y: 100,
            floating: true,
            backgroundColor: (Highcharts.theme && Highcharts.theme.legendBackgroundColor) || '#FFFFFF'
        },
        series: [{
            name: '里程數',
            type: 'column',
            yAxis: 1,
            data: [
		<?php
		 for($i=1;$i<=date('t');$i++)
		{
		echo $days_ex[$i][1].",";
		}?>],
            tooltip: {
                valueSuffix: ' m'
            }
        }, {
            name: '卡路里',
            type: 'spline',
            data: [
		<?php
		 for($i=1;$i<=date('t');$i++)
                {
                echo $days_ex[$i][2].",";
                }?>],
            tooltip: {
                valueSuffix: 'Kcal'
            }
        }]
    });
});
</script>
 <body>
 <div id="container" style="min-width: 310px; height: 400px; margin: 0 auto"></div> 
  <div id="container2" style="min-width: 310px; height: 400px; margin: 0 auto"></div> 
<center>
<input type="submit" value="主畫面" onclick="history.back(-1)"">
 <?php 
$db->close();
 ?>
 </body>
 </html>
