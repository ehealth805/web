<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>使用者資訊查詢</title>
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css"><!--匯入bootstrap-->
<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script><!--匯入jQuery-->
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script><!--匯入bootstrap javascript-->
</head>

<style type="text/css">
		h1 {
		text-align:center;
		background:#555;
		color:white;
		}
		table {
		font-family: arial, sans-serif;
    border-collapse: collapse;
    width: 70%;
	font-size:20px;
}

td, th {
    border: 1px solid #dddddd;
    text-align: center;
    padding: 8px;
}

tr:nth-child(even) {
    background-color: #dddddd;
	
}
</style>
<body>
<ul class="nav nav-tabs">
<div class="navbar-header">
                <a class="navbar-brand" href="#">
				<?php echo $_SESSION['school_name']; ?>
		</a>
            </div>
        <li><a href="home_page_student_v2.php">Home</a></li>
        <li><a href="user_data.php"><span class="glyphicon glyphicon-log-in"></span> 使用者資訊查詢</a></li>
        <li><a href="sportdata_search_date.php"><span class="glyphicon glyphicon-search"></span> 運動紀錄查詢</a></li>
		<li class="dropdown"><a lass="dropdown-toggle" data-toggle="dropdown" >
		<span class="glyphicon glyphicon-align-justify"></span> 分析排名<span class="caret"></span></a>
				<ul class="dropdown-menu">
				<li><a href="eight_hundred.php">心肺800M</a></li>
				<li><a href="eight_hundred_v2.php">心肺1600M</a></li>
                <li><a href="eight_hundred_v3.php">耐力3KM</a></li>
				<li><a href="#">耐力5KM</a></li>
				<li><a href="#">耐力10KM</a></li>
		</li></ul>
	<li class="dropdown"><a lass="dropdown-toggle" data-toggle="dropdown" >
        <span class="glyphicon glyphicon-align-justify"></span> 個人圖表<span class="caret"></span></a>
                <ul class="dropdown-menu">
	            <li><a href="#">月累積</a></li>
        	    <li><a href="#">年累積</a></li>
                </li></ul></ul>
</nav>
<h1><p class="title">使用者資訊查詢</p></h1>
<center>
<h2>
<?php
echo $_SESSION['school_name'];
 $db = new SQLite3('/var/www/html/exercise.db');//呼叫資料庫
 $userdata="SELECT * From userdata WHERE SID='".$_SESSION['SID']."'  AND CID='".$_SESSION['CID']."' ";
   $temp=$db->query($userdata);
    $result=$temp->fetchArray();
?></h2>
<table>
  <tr>
    <th>學號</th>
    <th>姓名</th>
    <th>班別</th>
	<th>性別</th>
	<th>身高(cm)</th>
	<th>體重(kg)</th>
	<th>e-mail</th>
	<th>晶片編碼</th>
  </tr>
  <tr>
    <td><?php echo  $result['SID'];?></td>
    <td><?php echo  $result['Name'];?></td>
    <td><?php echo  $result['Department'];?></td>
	<td><?php if($result['sex']=="1")
				echo  '男';
			  else
				echo  '女';?></td>
	<td><?php echo  $result['height'];?></td>
	<td><?php echo  $result['weight'];?></td>
	<td><?php echo  $result['email'];?></td>
	<td><?php echo  $result['tagid'];?></td>
  </tr>
</table>
<a href="home_page_student_v2.php" ><img src="Home.png" width="50" height="50" align="center"><br></a>回主畫面
 
</body>
</html>
