<?php
session_start();
$days = array (); #首先定义一个空數组
for($i=0;$i<=30;$i++)
{
$days[] = date("Y-m-d", strtotime(' -'. $i . 'day'));
}
// 從今天推回去30天都存在days陣列裡
$min=100;
$max=300;
$count=0;
$during =array(array(0,0));//all users
//$personal_count=0;//個人資料，count=次數
$personal_time=0;
$class_num=array();//班級，num=人數(不能重複)
$class_time=0;
$class_count=0;
$school_num=array();//學校
$school_time=0;
$school_count=0;
$school_average=0;
for($i=$min;$i<=$max;$i++)//X軸區間
{
	array_push($during,array($i,0));
}
$db = new SQLite3('/var/www/html/exercise.db');//呼叫資料庫
$ds=$days[30].' '.'00:00:00';
$dn=$days[0].' '.'23:59:59';
$time="SELECT *  FROM eight_hundred WHERE Date between '".$ds."' AND '".$dn."' AND CID= '".$_SESSION['CID']."' ";//抓取前30天資料
$temp=$db->query($time);
$user="SELECT * FROM userdata WHERE SID = '".$_SESSION['SID']."' ";
$temps=$db->query($user);
$user=$temps->fetchArray();
while($result=$temp->fetchArray())
{
	for($i=1;$i<=($max-$min);$i++){
		if($result['duration']==$during[$i][0] && $result['sex']==$user['sex'] )//all users 累積
		{
			$during[$i][1]++;
		}
	}
	if($result['CID']==$_SESSION['CID'])//同學校的判斷，目前沒有性別的判斷
                {
                        $school_time+=$result['duration'];
                        $school_count++;
                        $ans=find($school_num,$result['tagid']);
                        if($ans="-1")
                        {
                                array_push($school_num,$result['tagid']);
                        }
                }
	//echo  $result['Department'] ;
	if($result['Department'] == $user['Department'] && $result['CID']==$_SESSION['CID'])
		{
			$class_time+=$result['duration'];
			$class_count++;
			$ans=find($class_num,$result['tagid']);
                        if($ans="-1")
                        {
                                array_push($class_num,$result['tagid']);
                        }

		}

}
//echo $school_count.'<br>' ;
//echo count($school_num);
for($i=1;$i<=($max-$min+1);$i++)
{
$all_user+=$during[$i][1];
//echo $during[$i][1];
}
//echo $all_user;
$school_average=round($school_time/$school_count);
$class_average=round($class_time/$class_count);
//echo $class_time.'<br>'.$class_count;
//echo'<br>'. $class_average;
//echo  $during[($class_average-$min+1)][1];
?>
<?php
function find($array,$temp)
{ 
	for($i=0;$i<count($array);$i++)
			{
				if(array_search($temp,$array))
				{
					return 1;//有找到
				}
			else 
			{
				return -1;//沒有找到
			}
			}
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<script  type="text/javascript" src="http://code.jquery.com/jquery-1.8.3.min.js"></script>
<script type="text/javascript" src="http://code.highcharts.com/highcharts.js"></script>
<script type="text/javascript" src="https://code.highcharts.com/modules/exporting.js"></script>
<script  type="text/javascript" src="https://code.highcharts.com/modules/drilldown.js"></script>
<title>800公尺分析圖表</title>
<script>
$(function () {
    $('#container').highcharts({
        chart: {
            type: 'spline'
        },
        title: {
            text: '800M分析圖表'
        },
        subtitle: {
            text: 'Source: 智慧跑道系統'
        },
        xAxis: {
            categories: [<?php
                        for($i=1;$i<=($max-$min+1);$i++)
                        {
                        echo  $during[$i][0].",";
                        } ?>]
        },
        yAxis: {
            title: {
                text: '人數'
            }
    },
        tooltip: {
            crosshairs: true,
            shared: true,
		valueSuffix: ' 人'
        },
        plotOptions: {
            spline: {
                marker: {
                    radius: 4,
                    lineColor: '#666666',
                    lineWidth: 1
                }
            }
        },
        series: [{
            name: '使用者',
            marker: {
                symbol: 'square'
            },
            data: [<?php
                        for($i=1;$i<=($max-$min+1);$i++)
                        {
                        echo  $during[$i][1].",";
                        } ?>
                    ]}
]
    });
});
</script>
<script>
$(function () {
    $('#container2').highcharts({
        chart: {
            type: 'spline'
        },
        title: {
            text: '800M分析圖表'
        },
        subtitle: {
            text: 'Source: 智慧跑道系統'
        },
        xAxis: {
            categories: [<?php
                        for($i=1;$i<=($max-$min+1);$i++)
                        {
                        echo  $during[$i][0].",";
                        } ?>]
        },
        yAxis: {
            title: {
                text: '人數'
            }
    },
        tooltip: {
            crosshairs: true,
            shared: true,
		valueSuffix: ' 人'
        },
        plotOptions: {
            spline: {
                marker: {
                    radius: 4,
                    lineColor: '#666666',
                    lineWidth: 1
                }
            }
        },
        series: [{
		name: '全校使用者',
		marker: {
                symbol: 'square'
            },data:[[<?php echo $school_average-$min;?>,<?php echo $during[$school_average-$min][1];?>] ]
		}
		,{
                name: '班級使用者',
                marker: {
                symbol: 'diamond'
            },data:[[<?php echo $class_average-$min;?>,<?php echo $during[$class_average-$min][1];?>] ]
                }
]
    });
});
</script>
</head>
<body>
<div id="container" style="min-width: 310px; height: 400px; margin: 0 auto"></div>
<div id="container2" style="min-width: 310px; height: 400px; margin: 0 auto"></div>
<center>
<input type="submit" value="返回上一頁" onclick="history.back(-1)">
<?php
$db->close();
?>
</body>
</html>

