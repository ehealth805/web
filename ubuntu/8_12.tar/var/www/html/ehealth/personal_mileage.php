<?php
session_start();
$db = new SQLite3('/var/www/html/exercise.db');//呼叫資料庫
$c="select * FROM userdata WHERE CampusName='".$_SESSION['school_name']."' AND SID='".$_SESSION['SID']."' ";//抓取班級

?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>個人圖表</title>
</head>
<body>
</body>
</html>
